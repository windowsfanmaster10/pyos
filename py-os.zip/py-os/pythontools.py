import os
import time

act = input("Please wite Your Python Tool: ")

with open('Tools/script.py', 'w') as f:
	f.writelines(act)
