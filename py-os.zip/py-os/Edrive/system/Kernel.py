import os
print("""
[1] Back To System
[2] Trun Off Kernel
[3] Delete kernel
""")