import os

a = input("""
xxxxxxxxxxxxx
x           x
x    : /    x
x           x
xxxxxxxxxxxxx
Something Went Wrong
Your pc have deleted some programs but you are deleted files on your pc 
Press 1 To Back to your system
""")

a = input(":")

if a == '1':
    os.startfile('home.py')